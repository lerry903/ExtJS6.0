Ext.define('App.view.main.MainModel', {
    extend: 'App.view.main.MainModelShared',
    alias: 'viewmodel.main',
    stores: {
        beatles: {
            autoLoad: true,
            data: [
                {first: 'John'}, 
                {first: 'Paul'}, 
                {first: 'George'}, 
                {first: 'Ringo'}
            ],
            proxy: {type: 'memory'}
        }
    }
});