Ext.define('App.view.main.MainModel', {
    extend: 'App.view.main.MainModelShared',
    alias: 'viewmodel.main'
});