/**
 * This class is the controller for the main view for the application. It is specified as
 * the "controller" of the Main view class.
 *
 * TODO - Replace this content of this view to suite the needs of your application.
 */
Ext.define('App.view.main.MainController', {
    extend: 'App.view.main.MainControllerShared',

    alias: 'controller.main',

    onItemSelected: function (sender, record) {
        Ext.toast(record.data.name);
    }
});
