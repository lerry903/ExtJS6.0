Ext.define('Nms.panel.Panel', {
	override : 'Ext.panel.Panel',
	titleAlign : 'center'
});
